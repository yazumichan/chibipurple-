export async function GET() {
  return new Response(`<!DOCTYPE html>
<html>
<head>
<meta property="fc:frame" content="vNext"/>
<meta property="og:title" content="Chibi Purple"/>
<meta property="og:image" content="/chibi.png"/>
<meta property="fc:frame:image" content="/chibi.png"/>
<meta property="fc:frame:button:1" content="Mint 0.0001 BASE"/>
<meta property="fc:frame:button:1:action" content="tx"/>
</head>
<body></body></html>`, { headers:{ "Content-Type":"text/html"}});
}